import React from 'react';

export function CustomAbout() {
    return (
        <div data-testid="custom-about-settings">
        This is a custom about
        </div>
    );
}

export default CustomAbout;