import React from 'react';

export function CustomItemSettings() {
    return (
      <div data-testid="custom-item-settings">
        This is a custom item settings
      </div>
    );
  }

export default CustomItemSettings;