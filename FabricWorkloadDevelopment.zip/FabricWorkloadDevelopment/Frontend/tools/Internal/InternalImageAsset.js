class InternalImageAsset {
    constructor({name, dataUrl}) {
        this.name = name;
        this.dataUrl = dataUrl;
    }
}

module.exports = InternalImageAsset;