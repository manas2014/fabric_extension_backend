class InternalLocaleAsset {
    constructor({languageCode, translations}) {
        this.languageCode = languageCode;
        this.translations = translations;
    }
}

module.exports = InternalLocaleAsset;