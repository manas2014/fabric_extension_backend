﻿using Boilerplate.Constants;
using Boilerplate.Contracts;
using Boilerplate.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Boilerplate.Controllers
{
    [ApiController]
    public class WorkspacesController : ControllerBase
    {
        private static readonly IList<string> OneLakeScopes = new[] { $"{EnvironmentConstants.OneLakeResourceId}/.default" };
        private static readonly IList<string> ScopesForReadLakehouseFile = new[] { WorkloadScopes.FabricLakehouseReadAll, WorkloadScopes.FabricLakehouseReadWriteAll };
        private static readonly IList<string> ScopesForWriteLakehouseFile = new[] { WorkloadScopes.FabricLakehouseReadWriteAll };

        private readonly ILogger<WorkspacesController> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IAuthenticationService _authenticationService;
        private readonly IWorkspacesClientService _workspacesClientService;

        public WorkspacesController(
            ILogger<WorkspacesController> logger,
            IHttpContextAccessor httpContextAccessor,
            IAuthenticationService authenticationService,
            IWorkspacesClientService workspacesClientService)
        {
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _authenticationService = authenticationService;
            _workspacesClientService = workspacesClientService;
        }

        [HttpGet("getWorkspaces")]
        public async Task<IActionResult> GetWorkspaces(string source)
        {
            var authorizationContext = await _authenticationService.AuthenticateDataPlaneCall(_httpContextAccessor.HttpContext, allowedScopes: ScopesForReadLakehouseFile);
            var lakeHouseAccessToken = await _authenticationService.GetAccessTokenOnBehalfOf(authorizationContext, OneLakeScopes);

            var data = await _workspacesClientService.GetAllWorkspacesAsync(lakeHouseAccessToken);

            if (data == null || data.Count == 0)
            {
                _logger.LogWarning($"GetWorkspaces returned empty data for source: {source}");
                // Return a 204 No Content status code for empty data
                return NoContent();
            }

            _logger.LogInformation($"GetWorkspaces succeeded for source: {source}");
            return Ok(data);
        }

        [HttpGet("getWorkspace/{workspaceId}")]
        public async Task<IActionResult> GetWorkspaceById(Guid workspaceId)
        {
            var authorizationContext = await _authenticationService.AuthenticateDataPlaneCall(_httpContextAccessor.HttpContext, allowedScopes: ScopesForReadLakehouseFile);
            var lakeHouseAccessToken = await _authenticationService.GetAccessTokenOnBehalfOf(authorizationContext, OneLakeScopes);

            var workspace = await _workspacesClientService.GetWorkspaceByIdAsync(lakeHouseAccessToken, workspaceId);

            if (workspace == null)
            {
                _logger.LogWarning($"GetWorkspaceById returned null for workspaceId: {workspaceId}");
                // Return a 404 Not Found status code if the workspace is not found
                return NotFound();
            }

            _logger.LogInformation($"GetWorkspaceById succeeded for workspaceId: {workspaceId}");
            return Ok(workspace);
        }
    }
}
