using Boilerplate.Constants;
using Boilerplate.Contracts;
using Boilerplate.Services;
using Fabric_Extension_BE_Boilerplate.Contracts.FabricAPI.Workload;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Boilerplate.Controllers
{
    [ApiController]
    public class WorkloadsController : ControllerBase
    {
        private static readonly IList<string> OneLakeScopes = new[] { $"{EnvironmentConstants.OneLakeResourceId}/.default" };
        private static readonly IList<string> ScopesForReadLakehouseFile = new[] { WorkloadScopes.FabricLakehouseReadAll, WorkloadScopes.FabricLakehouseReadWriteAll };
        private static readonly IList<string> ScopesForWriteLakehouseFile = new[] { WorkloadScopes.FabricLakehouseReadWriteAll };

        private readonly ILogger<WorkloadsController> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IAuthenticationService _authenticationService;
        private readonly IWorkloadsClientService _workloadsClientService;

        public WorkloadsController(
            ILogger<WorkloadsController> logger,
            IHttpContextAccessor httpContextAccessor,
            IAuthenticationService authenticationService,
            IWorkloadsClientService workloadsClientService)
        {
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _authenticationService = authenticationService;
            _workloadsClientService = workloadsClientService;
        }

        [HttpPost("createItem/{workspaceId}/{itemType}/{itemId}")]
        public async Task<IActionResult> CreateItem(Guid workspaceId, string itemType, Guid itemId, [FromBody] CreateItemRequest createItemRequest)
        {
            var authorizationContext = await _authenticationService.AuthenticateDataPlaneCall(_httpContextAccessor.HttpContext, allowedScopes: ScopesForWriteLakehouseFile);
            var lakeHouseAccessToken = await _authenticationService.GetAccessTokenOnBehalfOf(authorizationContext, OneLakeScopes);

            var success = await _workloadsClientService.CreateItemAsync(lakeHouseAccessToken, workspaceId, itemType, itemId, createItemRequest);

            if (!success)
            {
                _logger.LogWarning($"CreateItem failed for workspaceId: {workspaceId}, itemType: {itemType}, itemId: {itemId}");
                // Return a 500 Internal Server Error status code if the item creation failed
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            _logger.LogInformation($"CreateItem succeeded for workspaceId: {workspaceId}, itemType: {itemType}, itemId: {itemId}");
            return Ok();
        }
    }
}

