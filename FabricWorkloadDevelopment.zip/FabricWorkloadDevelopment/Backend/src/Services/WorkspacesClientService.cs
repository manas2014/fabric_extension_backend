﻿using Boilerplate.Constants;
using Boilerplate.Contracts;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Linq;

namespace Boilerplate.Services
{
    /// <summary>
    /// Service for interacting with the Lakehouse storage.
    /// </summary>
    public class WorkspacesClientService : IWorkspacesClientService
    {
        private readonly ILogger<WorkspacesClientService> _logger;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientService _httpClientService;

        public WorkspacesClientService(
            IConfigurationService configuration,
            IHttpClientService httpClientService,
            ILogger<WorkspacesClientService> logger)
        {
            _logger = logger;
            _configuration = configuration.GetConfiguration();
            _httpClientService = httpClientService;
        }

        public async Task<List<Workspace>> GetAllWorkspacesAsync(string token)
        {
            var workspaces = new List<Workspace>();
            string url = $"{EnvironmentConstants.FabricApiBaseUrl}/v1/admin/workspaces";
            string continuationToken = null;

            do
            {
                var requestUrl = string.IsNullOrEmpty(continuationToken) ? url : $"{url}?continuationToken={continuationToken}";
                var response = await _httpClientService.GetAsync(requestUrl, token);

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<WorkspacesResponse>(content);

                    if (result?.Workspaces != null)
                    {
                        workspaces.AddRange(result.Workspaces);
                    }

                    continuationToken = result?.ContinuationToken;
                }
                else
                {
                    _logger.LogError($"Failed to retrieve workspaces. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}");
                    break;
                }
            } while (!string.IsNullOrEmpty(continuationToken));

            return workspaces;
        }

        public async Task<Workspace> GetWorkspaceByIdAsync(string token, Guid workspaceId)
        {
            string url = $"{EnvironmentConstants.FabricApiBaseUrl}/v1/admin/workspaces/{workspaceId}";
            var response = await _httpClientService.GetAsync(url, token);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Workspace>(content);
            }
            else
            {
                _logger.LogError($"Failed to retrieve workspace with ID: {workspaceId}. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}");
                return null;
            }
        }
    }

    public class WorkspacesResponse
    {
        [JsonProperty("workspaces")]
        public List<Workspace> Workspaces { get; set; }

        [JsonProperty("continuationToken")]
        public string ContinuationToken { get; set; }

        [JsonProperty("continuationUri")]
        public string ContinuationUri { get; set; }
    }

    public class Workspace
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("capacityId")]
        public string CapacityId { get; set; }
    }
}
