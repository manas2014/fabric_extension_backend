﻿using Boilerplate.Constants;
using Boilerplate.Contracts;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Linq;
using Fabric_Extension_BE_Boilerplate.Contracts.FabricAPI.Workload;

namespace Boilerplate.Services
{
    /// <summary>
    /// Service for interacting with the Lakehouse storage.
    /// </summary>
    public class WorkloadsClientService : IWorkloadsClientService
    {
        private readonly ILogger<WorkloadsClientService> _logger;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientService _httpClientService;

        public WorkloadsClientService(
            IConfigurationService configuration,
            IHttpClientService httpClientService,
            ILogger<WorkloadsClientService> logger)
        {
            _logger = logger;
            _configuration = configuration.GetConfiguration();
            _httpClientService = httpClientService;
        }


        public async Task<bool> CreateItemAsync(string token, Guid workspaceId, string itemType, Guid itemId, CreateItemRequest createItemRequest)
        {
            string url = $"{EnvironmentConstants.FabricApiBaseUrl}/workload-api-path-placeholder/workspaces/{workspaceId}/items/{itemType}/{itemId}";
            var requestContent = new StringContent(JsonConvert.SerializeObject(createItemRequest), Encoding.UTF8, "application/json");

            var response = await _httpClientService.PostAsync(url, requestContent, token);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                return true;
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogError($"Failed to create item. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Error: {errorContent}");
                return false;
            }
        }
    }
}

