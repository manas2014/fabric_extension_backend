﻿using Boilerplate.Contracts;
using Fabric_Extension_BE_Boilerplate.Contracts.FabricAPI.Workload;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Boilerplate.Services
{
    /// <summary>
    /// Represents a service for interacting with the Workloads.
    /// </summary>
    public interface IWorkloadsClientService
    {
        Task<bool> CreateItemAsync(string token, Guid workspaceId, string itemType, Guid itemId, CreateItemRequest createItemRequest);
    }
}
