﻿using Boilerplate.Contracts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Boilerplate.Services
{
    /// <summary>
    /// Represents a service for interacting with the Lakehouse storage.
    /// </summary>
    public interface IWorkspacesClientService
    {
        Task<List<Workspace>> GetAllWorkspacesAsync(string token);
        Task<Workspace> GetWorkspaceByIdAsync(string token, Guid workspaceId);
    }
}
