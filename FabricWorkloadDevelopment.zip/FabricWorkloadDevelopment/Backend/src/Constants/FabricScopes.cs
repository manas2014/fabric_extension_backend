﻿// <copyright company="Microsoft">
// Copyright (c) Microsoft. All rights reserved.
// </copyright>

namespace Boilerplate.Constants
{
    public static class FabricScopes
    {
        public const string LakehouseItemReadAll = "Lakehouse.Read.All";
    }
}
